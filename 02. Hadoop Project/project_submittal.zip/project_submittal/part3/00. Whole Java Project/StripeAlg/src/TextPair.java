import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;


public class TextPair implements WritableComparable<TextPair> {
	private Text left;
	private Text right;

	public TextPair() {
		set(new Text(), new Text());
	}

	public TextPair(String left, String right) {
		set(left, right);
	}

	public TextPair(Text left, Text right) {
		set(left, right);
	}

	void set(Text left, Text right) {
		this.left = left;
		this.right = right;
	}

	void set(String left, String right) {
		this.left = new Text(left);
		this.right = new Text(right);
	}

	public Text getLeft() {
		return left;
	}

	public Text getRight() {
		return right;
	}

	public void readFields(DataInput in) throws IOException {
		left.readFields(in);
		right.readFields(in);
	}

	public void write(DataOutput out) throws IOException {
		left.write(out);
		right.write(out);
	}

	public int compareTo(TextPair other) {
		int k = this.left.compareTo(other.left);
		if (k != 0)
			return k;
		return this.right.compareTo(other.right);
	}

	@Override
	public String toString() {
		return String.format("%s-%s", this.left.toString(), this.right.toString());
	}
}
