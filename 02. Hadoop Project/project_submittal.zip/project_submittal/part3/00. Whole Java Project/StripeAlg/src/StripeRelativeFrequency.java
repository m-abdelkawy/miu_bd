import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class StripeRelativeFrequency extends Configured implements Tool{
	
	public static class MapperForRFStripe extends Mapper<LongWritable, Text, Text, PrintMapWritable> {

		private static final IntWritable one = new IntWritable(1);

		@Override
		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			String line = value.toString();
			String[] lstProdId = line.split("\\s+");

			outer: for (int i = 0; i < lstProdId.length; i++) {
				PrintMapWritable map = new PrintMapWritable();
				inner: for (int j = i+1; j < lstProdId.length; j++) {
					if (lstProdId[i].equals(lstProdId[j])) {
						break;
					}
					if (map.containsKey(new Text(lstProdId[j]))) {
						IntWritable v = (IntWritable) map.get(new Text(lstProdId[j]));
						// v.set(v.get() + 1);
						map.put(new Text(lstProdId[j]), new IntWritable(v.get() + 1));
						//System.out.println(lstProdId[j] + ", " + map.get(new Text(lstProdId[j])));
					} else {
						map.put(new Text(lstProdId[j]), one);
					}
				}
				context.write(new Text(lstProdId[i]), map);
			}
		}

	}
	
	public static class ReducerForRFStripe extends Reducer<Text, PrintMapWritable, Text, PrintMapWritable> {

		@Override
		protected void reduce(Text key, Iterable<PrintMapWritable> values, Context context)
				throws IOException, InterruptedException {
			double sum = 0d;
			// System.out.println(key.toString() + " keyyyy");

			// Map<String, Integer> mapFinal = new HashMap<String, Integer>();

			PrintMapWritable mapFinal = new PrintMapWritable();

			for (MapWritable map : values) {
				for (Map.Entry<Writable, Writable> entry : map.entrySet()) {
					Text kTxt = (Text) entry.getKey();
					String k = ((Text) entry.getKey()).toString();
					int v = ((IntWritable) entry.getValue()).get();

					if (mapFinal.containsKey(kTxt)) {
						mapFinal.put(kTxt, new IntWritable(((IntWritable) mapFinal.get(kTxt)).get() + v));
					} else {
						mapFinal.put(kTxt, new IntWritable(v));
					}

					sum += v;
				}
			}

			for (Map.Entry<Writable, Writable> entry : mapFinal.entrySet()) {
				// System.out.println("(" + key.toString() + ", " + entry.getKey() + ")" + ", "
				// + (entry.getValue() / sum));
				//context.write(new TextPair(key, new Text(entry.getKey() + " sum: " + sum)),
					//	new DoubleWritable(entry.getValue() / sum));
				
				entry.setValue(new DoubleWritable(((IntWritable)entry.getValue()).get()/sum));
			}
			
			context.write(key, mapFinal);
		}
	}
	
	
	
	

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		// check if the output directory exists
		String outputLocation = args[1];
		Path path = new Path(outputLocation);
		FileSystem fs = path.getFileSystem(conf);

		if (fs.exists(path)) {
			fs.delete(path, true);
			System.out.println("Output directory deleted!");
		}

		int res = ToolRunner.run(conf, new StripeRelativeFrequency(), args);

		System.exit(res);
	}

	public int run(String[] args) throws Exception {
		Job job = new Job(getConf(), "relative_frequency_stripe");

		job.setJarByClass(StripeRelativeFrequency.class);

		job.setMapperClass(MapperForRFStripe.class);
		job.setReducerClass(ReducerForRFStripe.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(PrintMapWritable.class);

		//job.setPartitionerClass(KeyPartitioner.class);

		job.setOutputKeyClass(TextPair.class);
		job.setOutputValueClass(PrintMapWritable.class);

		Path input = new Path(args[0]);
		Path output = new Path(args[1]);
		FileInputFormat.addInputPath(job, input);
		FileOutputFormat.setOutputPath(job, output);

		return job.waitForCompletion(true) ? 0 : 1;

	}

}
