import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.io.MapWritable;

public class PrintMapWritable extends MapWritable {
	@Override
	public String toString() {
		List<String> lstPrint = new ArrayList<String>();
		for (MapWritable.Entry entry : this.entrySet()) {
			lstPrint.add(entry.toString());
		}
		return lstPrint.toString();
	}
}
