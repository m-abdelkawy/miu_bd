package averageLogInMapper;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.WritableComparable;

public class DoublePair implements WritableComparable<DoublePair> {
	private DoubleWritable left;
	private DoubleWritable right;

	DoublePair(DoubleWritable left, DoubleWritable right) {
		set(left, right);
	}

	DoublePair(double left, double right) {
		set(left, right);
	}

	DoublePair() {
		set(0, 0);
	}

	void set(DoubleWritable left, DoubleWritable right) {
		this.left = left;
		this.right = right;
	}

	void set(double left, double right) {
		this.left = new DoubleWritable(left);
		this.right = new DoubleWritable(right);
	}

	public DoubleWritable getLeft() {
		return left;
	}

	public DoubleWritable getRight() {
		return right;
	}

	public void readFields(DataInput in) throws IOException {
		left.readFields(in);
		right.readFields(in);
	}

	public void write(DataOutput out) throws IOException {
		left.write(out);
		right.write(out);
	}

	public int compareTo(DoublePair other) {
		int k = this.left.compareTo(other.left);
		if (k != 0)
			return k;
		return this.right.compareTo(other.right);
	}
}
