import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class AverageComputation  extends Configured implements Tool{

	public static class AverageMapper extends Mapper<Object, Text, Text, IntWritable> {

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

			String line = value.toString();
			String[] lineArray = line.split(" ");
			String ip = lineArray[0];
			Integer num = 0;
			try {
				num = Integer.parseInt(lineArray[9]);
			} catch (Exception e) {
				num = 0;
			}

			context.write(new Text(ip), new IntWritable(num));
		}

	}
	
	public static class AverageReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {
		private final DoubleWritable result = new DoubleWritable();

		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			double sum = 0;
			int count = 0;
			for (IntWritable val : values) {
				sum += val.get();
				count += 1;
			}
			result.set(sum/count);
			context.write(key, result);
		}
	}

	
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		// Check first if the directory exists
		String location = args[1];
		Path path = new Path(location);
		FileSystem fs = path.getFileSystem(conf);

		if (fs.exists(path)) {
			fs.delete(path, true);
			System.out.println("Output directory deleted!");
		}

		int res = ToolRunner.run(conf, new AverageComputation(), args);

		System.exit(res);
	}

	public int run(String[] args) throws Exception {
		Job job = new Job(getConf(), "averale-log");
		job.setJarByClass(AverageComputation.class);

		job.setMapperClass(AverageMapper.class);
		job.setReducerClass(AverageReducer.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		return job.waitForCompletion(true) ? 0 : 1;
	}
}
