import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;



public class InMapperCombiningWordCount  extends Configured implements Tool{
	public static class WordCountMapper extends Mapper<LongWritable, Text, Text, IntWritable>
	{

		Map<String, Integer> countMap = new HashMap<String, Integer>();

		@Override
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
		{
			StringTokenizer itr = new StringTokenizer(value.toString());
			while (itr.hasMoreTokens()) {
				String token = itr.nextToken();

				if (countMap.containsKey(token)) {
					int accumulativeCount = countMap.get(token) + 1;
					countMap.put(token, accumulativeCount);
				} else {
					countMap.put(token, 1);
				}
			}
		}
		
		@Override
		public void cleanup(Context context) throws IOException, InterruptedException{
			
			for (Map.Entry<String, Integer> entry : countMap.entrySet()) {
				String keyVal = entry.getKey();
				Integer countVal = entry.getValue();
				
				context.write(new Text(keyVal), new IntWritable(countVal));
			}
		}
	}

	public static class WordCountReducer extends Reducer<Text, IntWritable, Text, IntWritable>
	{
		private IntWritable result = new IntWritable();

		@Override
		public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException
		{
			int sum = 0;
			for (IntWritable val : values)
			{
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static void main(String[] args) throws Exception
	{
		Configuration conf = new Configuration();

		// check if the output directory exists
		String outputLocation = args[1];
		Path path = new Path(outputLocation);
		FileSystem fs = path.getFileSystem(conf);

		if (fs.exists(path)) {
			fs.delete(path, true);
			System.out.println("Output directory deleted!");
		}

		int res = ToolRunner.run(conf, new InMapperCombiningWordCount(), args);

		System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception
	{

		Job job = new Job(getConf(), "InMapperWordCount");
		job.setJarByClass(InMapperCombiningWordCount.class);

		job.setMapperClass(WordCountMapper.class);
		job.setReducerClass(WordCountReducer.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		Path input = new Path(args[0]);
		Path output = new Path(args[1]);
		FileInputFormat.addInputPath(job, input);
		FileOutputFormat.setOutputPath(job, output);

		return job.waitForCompletion(true) ? 0 : 1;
	}
}
