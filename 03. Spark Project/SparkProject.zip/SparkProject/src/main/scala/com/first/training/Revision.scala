package com.first.training

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object Revision {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("revision").setMaster("local")
    // Override output directory everytime you run the program
    conf.set("spark.hadoop.validateOutputSpecs", "false")

    val sc = new SparkContext(conf)

    /*val count1: RDD[Array[String]] = sc.textFile("wordCountInput").map(line => line.split("\\s+"))
    val count2: RDD[(String, Int)] = sc.textFile("wordCountInput").flatMap(line => line.split("\\s+"))
      .map(word => (word, 1))
      .reduceByKey((x, y) => x + y)

    for(n <- count2) println(n)

    val input: RDD[Int]  = sc.parallelize(List(7,5,2,9))

    val lines:RDD[String] = sc.parallelize(List("Once upon a time", "Spark came"))
    val words1: RDD[Array[String]] = lines.map(str => str.split("\\s+"))
    val words: RDD[String] = lines.flatMap(str => str.split("\\s+"))
    words.foreach(println)

    val numbers: RDD[Int] = sc.parallelize(List(7,2,9))
    val numberList:RDD[Int] = numbers.flatMap(x=>List(x*x, x*x*x))
    println(numberList.collect().mkString(", "))

    val one: RDD[Int] = sc.parallelize(List(1,2,3,4))
    val two: RDD[Int] = sc.parallelize(List(6,5,4,3))

    val oneUnionTwo :Array[(Int, Int)] = one.cartesian(two).collect()*/


    var myOne = List(
      List("cat", "mat", "bat"),
      List("hat", "mat", "rat"),
      List("cat", "mat", "sat"),
      List("cat", "fat", "bat")
    )

    myOne.foreach(println)

    var myTwo: RDD[List[String]] = sc.parallelize(myOne)
    myTwo.foreach(println)

    var myThree = myTwo.map(x=>(x(1), x(2)))
    myThree.foreach(println)

    var myFour = myThree.sortBy(_._1, true).sortBy(_._2)
    myFour.foreach(println)

    val data1 = Array(7,8,2,10,4,10,9,4)
    val rdd1 = sc.parallelize(data1)
    val max1 = rdd1.max()
    val rdd2 = rdd1.filter(_!= max1)
    val max2 = rdd2.max()
    println(max2)
  }

}
