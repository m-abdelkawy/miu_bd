package com.first.training

import org.apache.spark.{SparkConf, SparkContext}

object closureTraining {
  val factor: Int = 3
  val multiplier1 = (i: Int) => i * 10
  val multiplier2 = (i: Int) => i * factor

  def main(args: Array[String]): Unit = {
    println("multiplier1(1) value: " + multiplier1(1))
    println("multiplier1(2) value: " + multiplier1(2))

    println("multiplier2(1) value: " + multiplier2(1))
    println("multiplier2(2) value: " + multiplier2(2))


    //Given a list, determine whether there are more evens than odds
    val conf = new SparkConf().setAppName("FatalitiesMeanVariance").setMaster("local")
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    val numbers: Int = sc.parallelize(List(7,8,9,10,12)).map(x=>{
      if(x%2 == 0)
        1
      else
        -1
    }).reduce(_ + _)

    val numbers2: Int = sc.parallelize(List(7,8,9,10,12)).map(x=>{
      if(x%2 == 0)
        1
      else
        -1
    }).reduce((x, y) => x+y)

    println(numbers)
    println(numbers2)
  }
}
