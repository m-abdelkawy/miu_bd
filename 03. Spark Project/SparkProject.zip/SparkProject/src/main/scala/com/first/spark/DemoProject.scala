package com.first.spark

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ListBuffer

object DemoProject {
  val catIndex: Int = 2
  val catLabel: String = "cyl"
  val numIndex: Int = 1
  val numLabel: String = "mpg"

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("mtCars").setMaster("local")
    val sc = new SparkContext(conf);
    sc.setLogLevel("WARN")

    //load csv file
    val csv: RDD[String] = sc.textFile("mtcars.csv")

    val header: String = csv.first()

    val linesRddValsOnly: RDD[(Int, Iterable[Double])] = csv.filter(row => row != header).map(parseLine)
      .sortByKey().groupByKey().cache()

    val linesRdd2: RDD[(Int, Iterable[(Double, Int)])] = csv.filter(row => row != header).map(parseLine)
      .mapValues(x => (x, 1))
      .sortByKey().groupByKey().cache()

    val reducedToMeanAndVariance = linesRdd2.map(calcMeanVariance).collect()


    for (n <- linesRdd2) println(n)
    println("-----------------Plain Values")
    for (n <- linesRddValsOnly) println(n)
    println("-----------------Mean and Variance Together")
    display(reducedToMeanAndVariance)

    //Sampling

    //var sample: List[(Int, Seq[Double])] = createSample(linesRddValsOnly, false, 0.25, sc)
    var sample: RDD[(Int, Iterable[Double])] = createSample(linesRddValsOnly, false, 0.25, sc)


    println("________Sample___________")
    for (n <- sample) println(n)
    val sampleReducedToMeanAndVarianceArr: Array[(Int, Double, Double)] = sample
      .map(y => (y._1, y._2))
      .mapValues(x => x.map(v => (v, 1)))
      .map(calcMeanVariance).collect()

    display(sampleReducedToMeanAndVarianceArr)
    println("_______________Resampling_______________")
    var accumulated: ListBuffer[(Int, Seq[Double])] = new ListBuffer[(Int, Seq[Double])]()

    val numItr: Int = 10
    val i: Int = 0
    for (i <- 1 to 10) {
      var resample: RDD[(Int, Iterable[Double])] = createSample(linesRddValsOnly, true, 1d, sc)

      //accumulate values
      accumulateSamples(resample, accumulated, numItr)

      println("________Sample___________" + i)
      for (n <- resample) println(n)
      val resampleReducedToMeanAndVarianceArr: Array[(Int, Double, Double)] = resample
        .map(y => (y._1, y._2))
        .mapValues(x => x.map(v => (v, 1)))
        .map(calcMeanVariance).collect()

      display(resampleReducedToMeanAndVarianceArr)
    }
    println("_____________Accumulated ststistics")
    val accRdd = sc.parallelize(accumulated.toSeq)
    val accRddArr = accRdd
      .map(y => (y._1, y._2))
      .mapValues(x => x.map(v => (v, 1)))
      .map(calcMeanVariance).collect()

    display(accRddArr)


  }

  def parseLine(line: String) = {
    val fields = line.split(",");
    val catVal = fields(catIndex).toInt
    val numVal = fields(numIndex).toDouble
    (catVal, numVal)
  }

  def calcVariance(t: (Int, Iterable[(Double, Int)])): (Int, Double) = {
    val avgTuple = mean(t);
    val avg = avgTuple._2
    val count = t._2.count(_ => true)
    val variance = t._2.map(tup => math.pow(tup._1 - avg, 2)).reduce(_ + _) / count
    (t._1, variance)
  }

  def mean(t: (Int, Iterable[(Double, Int)])): (Int, Double) = {
    val count = t._2.count(_ => true)
    val avg = t._2.reduce((t1, t2) => (t1._1 + t2._1, 0))._1 / count
    (t._1, avg)
  }

  def calcMeanVariance(t: (Int, Iterable[(Double, Int)])): (Int, Double, Double) = {
    val count = t._2.count(_ => true)
    var avg: Double = 0
    var variance: Double = 0
    if (count != 0) {
      avg = t._2.reduce((t1, t2) => (t1._1 + t2._1, 0))._1 / count
      variance = t._2.map(tup => math.pow(tup._1 - avg, 2)).reduce(_ + _) / count
    }

    (t._1, avg, variance)
  }

  def display(lstTuple: Iterable[(Int, Double, Double)]): Unit = {
    var sb: StringBuilder = new StringBuilder("Category\tMean\tVariance\n")

    for (t <- lstTuple) {
      sb.append("       " + t._1 + "\t")
      val mean = t._2 - (t._2 % 0.01)
      val variance = t._3 - (t._3 % 0.01)
      sb.append(f"$mean%1.2f" + "\t")
      sb.append("   " + f"$variance%1.2f" + "\n")
    }
    println(sb)
  }

  def createSample(rdd: RDD[(Int, Iterable[Double])], withReplacement: Boolean, fraction: Double, sc: SparkContext)
  : /*List[(Int, Seq[Double])]*/ RDD[(Int, Iterable[Double])] = {
    val linesForSampling: Array[(Int, Seq[Double])] = rdd
      .mapValues(lst => lst.toSeq).collect()

    var sample: ListBuffer[(Int, Seq[Double])] = new ListBuffer[(Int, Seq[Double])]()

    for (n <- linesForSampling) {
      val x: RDD[Double] = sc.parallelize(n._2)
      val y: List[Double] = x.sample(false, 0.25).collect().toList

      sample += ((n._1, y.toSeq))
    }
    //sample.toList
    sc.parallelize(sample.toSeq)
  }

  /*def resample(rdd: RDD[(Int, Iterable[Double]),
    withReplacement: Boolean, fraction: Double,
  sc: SparkContext, numIteration: Int):RDD[(Int, Iterable[Double])]={

  }*/

  def accumulateSamples(rdd: RDD[(Int, Iterable[Double])], accumulated: ListBuffer[(Int, Seq[Double])], numItr: Int): Unit = {
    if (accumulated.size == 0) {
      rdd.collect().foreach(n => {
        accumulated += ((n._1, n._2.map(v => v / numItr).toSeq))
      })
      /*for (n <- rdd) {
        //sample += ((n._1, y.toSeq))
        accumulated += ((n._1, n._2.map(v => v / numItr).toSeq))
      }*/
    } else {
      var i: Int = 0
      for (n <- rdd.collect()) {
        val y: Iterable[Double] = (accumulated(i)._2.toList, n._2.map(v => v / numItr).toList).zipped.map(_ + _)
        accumulated(i) = (n._1, y.toSeq)
        i = i + 1
      }
    }
  }
}


