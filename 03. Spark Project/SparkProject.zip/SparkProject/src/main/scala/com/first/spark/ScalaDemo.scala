package com.first.spark

import java.io._
import scala.io.Source
import scala.math.random
import org.apache.spark._
import org.apache.spark.sql.{DataFrame, SQLContext}

object ScalaDemo {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("Spark and SparkSql").setMaster("local")
    val sc = new SparkContext(conf)


    sc.setLogLevel("WARN")

    // Exploring Scala and Spark

    def addInt(a: Int = 5, b: Int = 7): Int = {
      var sum: Int = 0
      sum = a + b
      sum
    }

    def ProductInt(a: Int = 5, b: Int = 7): Int = a * b

    println("Returned Sum  and Product are : " + addInt(10) + " and " + ProductInt(10));
    val myOne = List(List("cat", "mat", "bat"),
      List("hat", "mat", "rat"),
      List("cat", "mat", "sat"),
      List("cat", "fat", "bat"),
      List("eat", "fat", "cat"),
      List("hat", "fat", "pat"))

    myOne.foreach(println)

    println("MyTwo_____")
    val myTwo = sc.parallelize(myOne)
    myTwo.foreach(println)

    println("myThree______")
    val myThree = myTwo.map(x => (x(1), x(2)))
    myThree.foreach(println)

    println("myFour________")
    val myFour = myThree.sortBy(_._1, false).sortBy(_._2)
    myFour.foreach(println)

    //write, read, wordcount
    val writer = new PrintWriter(new File("result.txt"))
    writer.write("Hello World")


    val tf = sc.textFile("wordCountInput")
    val countsOne = tf
      .flatMap(line => line.split("\\s+"))
      .map(word => (word.toLowerCase(), 1))
      .reduceByKey(_ + _)
      .cache()

    val countsTwo = countsOne.sortByKey(true)
    countsTwo.foreach(println)

    val res = countsTwo.collect()
    for (n <- res) writer.println(n.toString())

    writer.close()

    // Exploring arrays and integers
    val data1 = Array(7, 8, 2, 10, 4, 10, 9, 4, 1, 6)
    val rdd1 = sc.parallelize(data1)
    val max1 = rdd1.max()
    println("max1: " + max1)
    val rdd2 = rdd1.filter(_ != max1)
    val max2 = rdd2.max()
    println("max2: " + max2)

    def getCount(in: Array[Int], start: Int, stop: Int): Int = {
      val cnt = in.map(x => {
        if (x >= start && x <= stop)
          1
        else
          0
      }).reduce(_ + _)
      cnt
    }

    println(getCount(data1, 4, 7))

    println("_______________________")

    // processing access log files using Spark
    def isNumeric(input: String): Boolean = input.forall(_.isDigit)

    val accessLog = sc.textFile("access_log").cache()
    val logRecord = accessLog
      .filter(line => (line.split("\\s+").size > 9 && isNumeric(line.split("\\s+")(9))))
      .map(line => (line.split("\\s+")(0), line.split("\\s+")(9)))
      .filter(x => x._2 != "0").cache()

    def getIP(in: String): String = {
      in.split("\\s+")(0)
    }

    def getSite(in: String): String = {
      in.split("\\s+")(6)
    }

    def getSize(in: String): String = {
      val x = in.split("\\s+");
      if (x.count(_ => true) > 9)
        x(9)
      else
        "0"
    }

    val data = accessLog
    val cleanData = data.map(line => (getIP(line), getSize(line)))
      .filter(t => t._2 != "-" && t._2 != "" && t._2 != "0" /*&& t._1 == "64.242.88.10"*/).cache()

    val cleanDataInt = cleanData.map(t => (t._1, t._2.toInt))
    val cleanDataIntGroup = cleanDataInt.groupByKey()

    for (n <- cleanDataInt) println(n.toString())
    println("______________")
    for (n <- cleanDataIntGroup) println(n.toString())

    println("______________")

    val cleanDataIntGroupMap = cleanDataIntGroup
      .map(rec => (rec._1, (rec._2.count(_ => true), rec._2.reduce(_ + _))))

    for (n<-cleanDataIntGroupMap) println(n.toString())
    println("_______________")
    val cleanDataIntGroupMapAvg = cleanDataIntGroupMap
      .map(rec => (rec._1, rec._2._2/rec._2._1))
    for(n<-cleanDataIntGroupMapAvg) println(n.toString())

    println("________________________________")
    cleanDataIntGroupMapAvg.sortBy(_._1, true).top(10).foreach(println)
  }
}
