package com.first.spark


import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable

//From Daniel

object MeanVarianceProgram {

  var sc: SparkContext = null

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName("meanVarianceCalculator")
    conf.setMaster("local")
    // Override output directory everytime you run the program
    conf.set("spark.hadoop.validateOutputSpecs", "false")

    sc = new SparkContext(conf);
    sc.setLogLevel("ERROR")

    val inputFilePath = args(0)
    val outputFilePath = args(1)

    calculateMeanVariance(inputFilePath, outputFilePath)
  }

  private def calculateMeanVariance(inputFilePath: String, outputFilePath: String): Unit = {

    val textFile = sc.textFile(inputFilePath);

    val population = textFile
      .map(s => (s.split(",")(2), s.split(",")(5).toDoubleOption))
      .filter(tuple => tuple._1.nonEmpty && tuple._2.isDefined)
      .map(tuple => (tuple._1, tuple._2.get))
      .groupByKey()
      .sortByKey()
      .persist()

    val result = population.map(tuple => (tuple._1, calculateMean(tuple._2), calculateVariance(tuple._2))).collect()

    result.foreach(tuple => {

      println(tuple._1 + " (" + tuple._2 + " ," + tuple._3 + ")")

    })

    val rddResult = sc.parallelize(result)

    rddResult.saveAsTextFile(outputFilePath + "population")


    val resultMap = new mutable.HashMap[String, (Double, Double)]()

    population.collect().foreach(tuple => {
      val sample = samplePopulation(tuple._2)
      var mean: Double = 0.0;
      var variance: Double = 0.0
      var count: Int = 0;

      for (_ <- 1 to 10) {
        val resampled = sample.sample(true, 1)
        mean += calculateMean(resampled.collect().toSeq)
        variance += calculateVariance(resampled.collect().toSeq)
        count += 1
      }

      val avgMean = mean / count
      val avgVariance = variance / count
      resultMap.put(tuple._1, (avgMean, avgVariance))
    })
    println("------------------Sampled---------------------")
    resultMap.foreach {
      case (key, value) => println(key + " (" + value._1 + " ," + value._2 + ")")
    }

    val rddResultMap = sc.parallelize(resultMap.toSeq)

    rddResultMap.saveAsTextFile(outputFilePath + "sampled")
  }


  private def samplePopulation(values: Iterable[Double]): RDD[Double] = {

    val sample = sc.parallelize(values.toSeq).sample(false, 0.25)
    sample
  }


  private def calculateMean(values: Iterable[Double]): Double = {

    var count: Int = 0;
    var sum: Double = 0.0;

    values.foreach(num => {

      sum += num
      count += 1
    })

    var mean = 0.0;

    if (sum != 0.0) {
      mean = sum / count;
    }

    mean

  }

  private def calculateVariance(values: Iterable[Double]): Double = {
    var count: Int = 0;
    var sum: Double = 0.0;
    var squareSum: Double = 0.0;

    values.foreach(num => {
      sum += num;
      squareSum += (num * num)
      count += 1;
    })
    var mean = 0.0;
    if (sum != 0.0) {
      mean = sum / count;
    }
    var avgSquareSum = 0.0
    if (squareSum != 0.0) {
      avgSquareSum = squareSum / count
    }
    val variance: Double = (avgSquareSum) - (mean * mean)

    variance
  }

}
