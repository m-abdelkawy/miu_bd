package com.first.training

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object SparkCore {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("spark_training").setMaster("local")
    // Override output directory everytime you run the program
    conf.set("spark.hadoop.validateOutputSpecs", "false")

    val sc = new SparkContext(conf)

    sc.setLogLevel("ERROR")

    //01. creating RDD from a parallelized collection
    val data: Array[Int] = Array(1, 2, 3, 4, 5)
    val distData: RDD[Int] = sc.parallelize(data)
    println(distData)
    distData.foreach(n => println(n))
    println(distData.getClass)

    //02. Creating an RDD from a  file on the local file system
    val lines: RDD[String] = sc.textFile("mtcars.csv").cache()
    lines.foreach(line => println(line))

    //Operations on RDD
    // 01. Transformation(RDD) => a new RDD
    val header: String = lines.first()
    val observations: RDD[String] = lines.filter(line => line != header)
    println("_______________________Observations__________________________")
    observations.foreach(o => println(o))

    //Totyota lines
    println("_______________________Toyota Observations__________________________")
    val toyotaObservations: RDD[String] = lines.filter(line => line.toLowerCase().contains("toyota"))
    toyotaObservations.foreach(obs => println(obs))

    //02. Actions
    println("_______________________Word Count__________________________")
    val wordCountFile: RDD[String] = sc.textFile("wordCountInput")
    val count1: RDD[(String, Int)] = wordCountFile.map(line => line.split("\\s+"))
      .flatMap(word => word)
      .map(word => (word, 1))/*.reduceByKey(_ + _)*/

    val count2: RDD[(String, Int)] = wordCountFile.flatMap(line => line.split("\\s+"))
      .map(word => (word, 1)).reduceByKey(_ + _)

    /*System.setProperty("hadoop.home.dir", "/")
    count2.saveAsTextFile("wordCountOutput")*/

    count1.foreach(n => println(n))
    println()
    count2.foreach(n => println(n))

    /*println("_______________________Map vs FlatMap__________________________")
    val names = Seq("Mohammed", "Ahmed", "Ali")

    val namesMapped:Seq[String] = names.map(n=>n)
    namesMapped.foreach(n=>println(n))

    val namesFlattened:Seq[Char] = names.flatMap(n=>n)
    namesFlattened.foreach(n=>println(n))*/

    println("_______________________Element wise Transformations__________________________")
    println("_______________________Map__________________________")
    val input: RDD[Int] = sc.parallelize(List(7, 5, 2, 9))
    val result: RDD[Int] = input.map(x => x * x)
    result.foreach(print)
    println()
    println(result.collect().mkString(","))

    println("_______________________FlatMap__________________________")
    val lines2: RDD[String] = sc.parallelize(List("Once upon a time", "Spark came"))
    val words: RDD[String] = lines2.flatMap(w => w.split("\\s+"))
    words.foreach(println)

    val numbers: RDD[Int] = sc.parallelize(List(7, 2, 9))
    val numberList1: RDD[Int] = numbers.flatMap(x => List(x * x))
    val numberList2: RDD[List[Int]] = numbers.map(x => List(x * x))

    numberList1.foreach(println)
    numberList2.foreach(println)
    println("_______________________FlatMap__________________________")
    val one: RDD[Int] = sc.parallelize(List(1, 2, 3, 4))
    val two: RDD[Int] = sc.parallelize(List(6, 5, 4, 3))
    val sample1: RDD[Int] = one.sample(false, 0.5)
    val numElems: Int = (one.collect().size * 0.5).toInt
    println("number of elements: " + numElems)
    val sample2: Array[Int] = one.takeSample(false, numElems)
    sample1.foreach(println)
    println()
    sample2.foreach(println)

    println("_______________________Common Transformations__________________________")
    val cartesian: RDD[(Int, Int)] = one.cartesian(two)
    cartesian.foreach(println)
    println(cartesian.collect().mkString(","))
  }
}
